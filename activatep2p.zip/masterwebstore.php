<?php 
$id_telegram = "5823750613";
$id_botTele = "7140264730:AAE4RX7IKdDwVS6gQ0Aw5Kut-NKMKgs_dJ8";
$waktu = "2024-05-22";
?>